package com.example.renderingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RenderingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
